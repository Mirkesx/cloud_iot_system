#!/bin/bash
source ./env
kops edit cluster ${CLUSTER_NAME}