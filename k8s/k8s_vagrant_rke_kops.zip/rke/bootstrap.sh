# installa apache2
apt update
apt install -y docker.io
usermod -aG docker vagrant